
"use strict";

let ResizedImage = require('./ResizedImage.js');

module.exports = {
  ResizedImage: ResizedImage,
};
